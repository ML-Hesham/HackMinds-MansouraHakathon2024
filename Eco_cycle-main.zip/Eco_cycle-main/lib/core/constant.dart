import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const Color kPrimaryColor = Color(0xff9DD549);
const kTranstionDuration = Duration(microseconds: 250);
const kGTSectraFine = 'GT Sectra Fine';
